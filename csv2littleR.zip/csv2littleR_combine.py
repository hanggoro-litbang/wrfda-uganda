#!/usr/bin/env python3

import sys
import random
from pathlib import Path
import pandas as pd

DEBUG = False

if DEBUG:
    random.seed(42)

# ==========================================================
# CONSTANTS
# ==========================================================

EMPTY_VAL = -888888.00000
END_VAL = -777777.00000
QC_VAL = 0

# ==========================================================
# FORMATTERS
# ==========================================================

def fmt_float(x):
    return f"{float(x):13.5f}"

def fmt_int(x):
    return f"{int(x):7d}"

def r_random_0_99():
    """
    Meniru floor(runif(1)*100) pada script R
    """
    return int(random.random() * 100)

# ==========================================================
# UNIT CONVERSIONS
# ==========================================================

def convert_pressure(x):
    if pd.isna(x) or float(x) == EMPTY_VAL:
        return EMPTY_VAL
    return float(x) * 100.0

def convert_temperature(x):
    if pd.isna(x) or float(x) == EMPTY_VAL:
        return EMPTY_VAL
    return float(x) + 27315e-2  # 273.15

def convert_wind(x):
    if pd.isna(x) or float(x) == EMPTY_VAL:
        return EMPTY_VAL
    return float(x) * 0.514444

# ==========================================================
# HEADER RECORD
# ==========================================================

def build_header(header):

    code = str(header["CODE"]).strip()

    if "35" in code:
        code_name = "FM-35  TEMP"
        is_sound = "T"
    elif "12" in code:
        code_name = "FM-12  SYNOP"
        is_sound = "F"
    else:
        code_name = code
        is_sound = "F"

    dt = str(header["DATE_TIME"]).strip()

    yyyy = dt[0:4]
    mm   = dt[5:7]
    dd   = dt[8:10]
    hh   = dt[11:13]
    mn   = dt[14:16]

    date_time = f"{yyyy}{mm}{dd}{hh}{mn}00"

    slp = convert_pressure(header["SEA_LEVEL_PRESSURE"])
    sfc = convert_pressure(header["SURFACE_PRESSURE"])

    line = ""

    line += f"{float(header['LAT']):20.5f}"
    line += f"{float(header['LON']):20.5f}"

    line += f"{str(header['ID']):<40}"
    line += f"{str(header['STA_NAME'])[:40]:<40}"
    line += f"{code_name:<40}"
    line += f"{str(header['SOURCE'])[:40]:<40}"

    line += f"{float(header['ELEVATION']):20.5f}"

    line += f"{int(EMPTY_VAL):10d}"   # valid field
    line += f"{int(EMPTY_VAL):10d}"   # num errors
    line += f"{int(EMPTY_VAL):10d}"   # num warnings

    line += f"{r_random_0_99():10d}"
    
    line += f"{int(EMPTY_VAL):10d}"   # num duplicates

    line += f"{is_sound:>10}"
    line += f"{'F':>10}"
    line += f"{'F':>10}"

    line += f"{int(EMPTY_VAL):10d}"   # unix time
    line += f"{int(EMPTY_VAL):10d}"   # julian day

    line += f"{date_time:>20}"

    # SLP
    line += fmt_float(slp)
    line += fmt_int(QC_VAL)

    # Ref Pressure
    line += fmt_float(EMPTY_VAL)
    line += fmt_int(QC_VAL)

    # Ground Temp
    line += fmt_float(EMPTY_VAL)
    line += fmt_int(QC_VAL)

    # SST
    line += fmt_float(EMPTY_VAL)
    line += fmt_int(QC_VAL)

    # Surface Pressure
    line += fmt_float(sfc)
    line += fmt_int(QC_VAL)

    # Optional fields
    for _ in range(9):
        line += fmt_float(EMPTY_VAL)
        line += fmt_int(QC_VAL)

    return line

# ==========================================================
# DATA RECORD
# ==========================================================

def build_data_line(row):

    vals = [
        row["PRES"],
        row["HGHT"],
        row["TEMP"],
        row["DWPT"],
        row["WSPEED"],
        row["WDRCT"],
        row["UWND"],
        row["VWND"],
        row["RELH"],
        row["THICKNESS"],
    ]

    line = ""

    for v in vals:
        if pd.isna(v):
            v = EMPTY_VAL

        line += fmt_float(v)
        line += fmt_int(QC_VAL)

    return line

# ==========================================================
# END RECORD
# ==========================================================

def build_end_record():

    vals = [
        END_VAL, END_VAL, EMPTY_VAL, EMPTY_VAL, EMPTY_VAL,
        EMPTY_VAL, EMPTY_VAL, EMPTY_VAL, EMPTY_VAL, EMPTY_VAL,
    ]

    line = ""

    for v in vals:
        line += fmt_float(v)
        line += fmt_int(QC_VAL)

    return line

# ==========================================================
# TAIL RECORD
# ==========================================================

def build_tail_record():
    return (
        f"{r_random_0_99():7d}"
        f"{QC_VAL:7d}"
        f"{QC_VAL:7d}"
    )

# ==========================================================
# READ BMKG CSV
# ==========================================================

def read_bmkg_csv(csv_file):

    header = pd.read_csv(
        csv_file,
        nrows=1,
        dtype={"DATE_TIME": str}
    ).iloc[0]

    data = pd.read_csv(
        csv_file,
        skiprows=2
    )

    # hapus kolom kosong akibat trailing comma
    data = data.loc[:, ~data.columns.str.contains("^Unnamed")]
    data.columns = data.columns.str.strip()

    return header, data

# ==========================================================
# PROCESS SINGLE FILE
# ==========================================================

def process_csv(csv_file):

    header, data = read_bmkg_csv(csv_file)

    # Unit conversions
    data["PRES"] = data["PRES"].apply(convert_pressure)
    data["TEMP"] = data["TEMP"].apply(convert_temperature)
    data["DWPT"] = data["DWPT"].apply(convert_temperature)
    data["WSPEED"] = data["WSPEED"].apply(convert_wind)
    data["UWND"] = data["UWND"].apply(convert_wind)
    data["VWND"] = data["VWND"].apply(convert_wind)

    lines = []
    lines.append(build_header(header))

    for _, row in data.iterrows():
        lines.append(build_data_line(row))

    lines.append(build_end_record())
    lines.append(build_tail_record())

    return lines

# ==========================================================
# PROCESS SINGLE CYCLE DIRECTORY
# ==========================================================

def build_cycle_lines(cycle_dir, obs):
    """
    Bangun seluruh baris little-R untuk satu folder cycle.
    Return (cycle_name, lines) atau (cycle_name, None) jika folder kosong.
    """

    cycle = cycle_dir.name
    csv_files = sorted(cycle_dir.glob("*.csv"))

    if not csv_files:
        print(f"[-] Folder {cycle} kosong (Tidak ada file .csv). Melewati...")
        return cycle, None

    print(f"\n==========================================")
    print(f"MEMPROSES CYCLE : {cycle} ({obs})")
    print(f"==========================================")
    print(f"{len(csv_files)} files ditemukan.")

    all_lines = []

    for i, csv_file in enumerate(csv_files, start=1):
        if i % 50 == 0:
            print(f"   Processed {i}/{len(csv_files)} files...")

        try:
            all_lines.extend(process_csv(csv_file))
        except Exception as e:
            print(f"ERROR memproses file: {csv_file.name}")
            print(e)

    print(f"[+] {len(csv_files)} files berhasil dikonversi ({obs}, {cycle}).")

    return cycle, all_lines


def write_lines(output_file, lines):
    with open(output_file, "w", newline="\n") as f:
        f.write("\n".join(lines))
        f.write("\n")   # penting agar jumlah baris sama dengan output R

    print(f"[+] Output selesai: {output_file.name}")

# ==========================================================
# MAIN
# ==========================================================

def main():

    try:
        project_root = Path(__file__).resolve().parent
    except NameError:
        project_root = Path.cwd()

    import argparse

    parser = argparse.ArgumentParser(
        description="Konversi CSV BMKG (sinop & temp) ke format little-R."
    )
    parser.add_argument(
        "cycle", nargs="?", default=None,
        help="Nama folder cycle spesifik yang ingin diproses (opsional). "
             "Jika tidak diisi, semua folder cycle akan diproses."
    )
    parser.add_argument(
        "--combine", action="store_true",
        help="Gabungkan output sinop dan temp untuk cycle yang sama "
             "menjadi satu file grobs.{cycle}, alih-alih dua file terpisah "
             "grobs_sinop.{cycle} dan grobs_temp.{cycle}."
    )
    args = parser.parse_args()

    obs_list = ["sinop", "temp"]

    # results[cycle][obs] = list of lines
    results = {}

    for obs in obs_list:

        input_base_dir = project_root / "data" / f"{obs}"

        if not input_base_dir.exists():
            print(f"[-] Folder data '{obs}' tidak ditemukan di path berikut: {input_base_dir}. Melewati...")
            continue

        # 1. Jika ada parameter cycle spesifik (proses 1 folder spesifik)
        if args.cycle:
            cycle_dir = input_base_dir / args.cycle
            if cycle_dir.exists() and cycle_dir.is_dir():
                cycle, lines = build_cycle_lines(cycle_dir, obs)
                if lines:
                    results.setdefault(cycle, {})[obs] = lines
            else:
                print(f"❌ Folder cycle '{args.cycle}' tidak ditemukan di dalam data/{obs}.")

        # 2. Jika tidak ada parameter, otomatis proses semua folder di dalam data/{obs}
        else:
            cycle_dirs = [d for d in input_base_dir.iterdir() if d.is_dir()]

            if not cycle_dirs:
                print(f"❌ Tidak ada folder data apapun di dalam: {input_base_dir}")
                continue

            print(f"Mendeteksi {len(cycle_dirs)} folder cycle di data/{obs}. Memulai pemrosesan otomatis...")

            for cycle_dir in sorted(cycle_dirs):
                cycle, lines = build_cycle_lines(cycle_dir, obs)
                if lines:
                    results.setdefault(cycle, {})[obs] = lines

    # ------------------------------------------------------------
    # Tulis output: gabungan (--combine) atau terpisah per obs
    # ------------------------------------------------------------
    for cycle in sorted(results.keys()):
        obs_lines = results[cycle]

        if args.combine:
            combined = []
            for obs in obs_list:
                if obs in obs_lines:
                    combined.extend(obs_lines[obs])

            output_file = project_root / f"grobs.{cycle}"
            write_lines(output_file, combined)
        else:
            for obs, lines in obs_lines.items():
                output_file = project_root / f"grobs_{obs}.{cycle}"
                write_lines(output_file, lines)

    print("\n✅ SEMUA PROSES SELESAI.")

# ==========================================================
# ENTRY POINT
# ==========================================================

if __name__ == "__main__":
    main()